# issuance-event

The initial transaction event log event anchored to the issuing AID’s key event log that represents the issuance of an ACDC credential.
Source: Philip Feairheller.

It's a sort of "[inception event](https://weboftrust.github.io/WOT-terms/docs/glossary/inception-event.md)" of a verifiable credential.