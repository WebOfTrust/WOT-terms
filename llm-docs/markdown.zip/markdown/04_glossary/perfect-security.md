# perfect-security

a special case of Information theoretic security [ITPS](https://weboftrust.github.io/WOT-terms/docs/glossary/itps.md).
Source: Dr. S. Smith