# self-sovereignty

[Self sovereignty](https://github.com/trustoverip/toip/wiki/self-sovereignty) in Trust over IP wiki.