# DKMI

[Decentralized key management infrastructure](https://weboftrust.github.io/WOT-terms/docs/glossary/decentralized-key-management-infrastructure.md)