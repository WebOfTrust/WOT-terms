# kli

[KERI command line interface](https://weboftrust.github.io/WOT-terms/docs/glossary/keri-command-line-interface.md)