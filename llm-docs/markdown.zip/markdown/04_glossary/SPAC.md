# SPAC

[Secure Private Authentic Confidentiality](https://weboftrust.github.io/WOT-terms/docs/glossary/secure-private-authentic-confidentiality.md)