# self-addressed-data

a representation of data content from which a SAID is derived. The SAID is both cryptographically bound to (content-addressable) and encapsulated by (self-referential) its SAD [SAID](https://weboftrust.github.io/WOT-terms/docs/glossary/said.md).
Source: Dr. S.Smith