# RID

[Root autonomic identifier](https://weboftrust.github.io/WOT-terms/docs/glossary/root-autonomic-identifier.md)