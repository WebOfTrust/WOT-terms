# vlei-role-credential

It is a [vLEI credential](https://weboftrust.github.io/WOT-terms/docs/glossary/vlei-credential.md) that attests to a role within a legal entity to an individual or an entity. It cryptographically proves that the individual or entity is authorized to act in that role on behalf of the legal entity.