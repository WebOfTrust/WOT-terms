# OOBI

[Out-of-band introduction](https://weboftrust.github.io/WOT-terms/docs/glossary/out-of-band-introduction.md)