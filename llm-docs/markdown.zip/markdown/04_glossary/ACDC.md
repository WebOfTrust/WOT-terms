# ACDC

[authentic chained data container](https://weboftrust.github.io/WOT-terms/docs/glossary/authentic-chained-data-container.md)