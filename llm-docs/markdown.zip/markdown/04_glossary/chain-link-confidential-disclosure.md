# chain-link-confidential-disclosure

contractual restrictions and liability imposed on a recipient of a disclosed [ACDC](https://weboftrust.github.io/WOT-terms/docs/glossary/ACDC.md) that contractually link the obligations to protect the disclosure of the information contained within the ACDC to all subsequent recipients as the information moves downstream. The Chain-link Confidential Disclosure provides a mechanism for protecting against un-permissioned exploitation of the data disclosed via an ACDC.
Source: Dr. S.Smith