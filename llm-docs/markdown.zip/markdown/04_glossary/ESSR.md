# ESSR

[Encrypt‐Sender‐Sign‐Receiver](https://github.com/WebOfTrust/WOT-terms/wiki/encrypt-sender-sign-receiver)