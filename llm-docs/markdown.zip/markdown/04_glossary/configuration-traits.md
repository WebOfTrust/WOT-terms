# Configuration traits

a list of specially defined strings representing a configuration of a [KEL](https://weboftrust.github.io/WOT-terms/docs/glossary/key-event-log.md). See [Configuration traits field](#configuration-traits-field).
Source: Dr. S.Smith, 2024