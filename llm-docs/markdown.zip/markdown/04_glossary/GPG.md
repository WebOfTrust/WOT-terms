# GPG

[Gnu privacy guard](https://weboftrust.github.io/WOT-terms/docs/glossary/gnu-privacy-guard.md)