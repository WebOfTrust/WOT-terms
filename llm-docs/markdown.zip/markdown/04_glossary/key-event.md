# key-event

Concretely, it is the serialized data structure of an entry in the Key event log (KEL) for an AID. Abstractly, the data structure itself. Key events come in different types and are used primarily to establish or change the authoritative set of keypairs and/or anchor other data to the authoritative set of keypairs at the point in the KEL actualized by a particular entry.
Source [Sam Smith](https://github.com/WebOfTrust/ietf-keri/blob/main/draft-ssmith-keri.md#basic-terminology)

Events happening to controlling keys of an identifier recorded in a Key Event Log (KEL).

A _key event_ is data structure that consist of a header (Key Event header), a configuration section (Key Event Data spans Header and configuration) and signatures (Key event Message spans Data and signatures)
(_@henkvancann_)

![](https://github.com/WebOfTrust/keri/blob/main/images/Key-Event.png)