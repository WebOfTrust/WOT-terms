# APC

[Authentic provenance chain](https://weboftrust.github.io/WOT-terms/docs/glossary/authentic-provenance-chain.md)