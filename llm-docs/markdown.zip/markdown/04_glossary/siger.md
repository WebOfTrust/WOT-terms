# siger

[Indexed signature](https://weboftrust.github.io/WOT-terms/docs/glossary/indexed-signature.md)