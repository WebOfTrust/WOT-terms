# KAWA

[KERI’s Algorithm for Witness Agreement](https://weboftrust.github.io/WOT-terms/docs/glossary/keri’s-algorithm-for-witness-agreement.md)