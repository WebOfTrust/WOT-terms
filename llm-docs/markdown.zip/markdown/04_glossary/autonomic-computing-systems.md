# autonomic-computing-systems

Self managing computing systems using algorithmic governance, from the 90's way way way before DAOs. KERI creator Sam Smith worked at funded Navy research in the 90's on autonomic survivable systems as in "self-healing" systems: "We called them autonomic way back then".