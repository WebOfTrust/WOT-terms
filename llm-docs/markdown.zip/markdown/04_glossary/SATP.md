# SATP

[Secure asset transfer protocol](https://weboftrust.github.io/WOT-terms/docs/glossary/secure-asset-transfer-protocol.md)