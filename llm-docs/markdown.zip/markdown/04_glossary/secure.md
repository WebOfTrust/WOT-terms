# secure

[Security](https://weboftrust.github.io/WOT-terms/docs/glossary/security.md)