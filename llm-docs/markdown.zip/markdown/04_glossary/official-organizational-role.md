# official-organizational-role

Also 'OOR'. A person that represents the Legal Entity in an official organizational role and is issued an OOR vLEI Credential.
[Source](https://www.gleif.org/vlei/introducing-the-vlei-ecosystem-governance-framework/2022-02-07_verifiable-lei-vlei-ecosystem-governance-framework-glossary-draft-publication_v0.9-draft.pdf) Draft vLEI Ecosystem Governance Framework Glossary.