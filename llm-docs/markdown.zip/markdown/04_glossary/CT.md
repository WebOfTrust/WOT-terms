# CT

[Certificate transparency](https://weboftrust.github.io/WOT-terms/docs/glossary/certificate-transparency.md)