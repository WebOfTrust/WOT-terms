# drt

drt = deltate, delegated rotation