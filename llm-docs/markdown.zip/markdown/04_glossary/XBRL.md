# XBRL

[eXtensible Business Reporting Language](https://weboftrust.github.io/WOT-terms/docs/glossary/extensible-business-reporting-language.md)