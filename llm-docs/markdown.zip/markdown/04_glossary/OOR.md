# OOR

[Official Organizational Role](https://weboftrust.github.io/WOT-terms/docs/glossary/official-organizational-role.md)