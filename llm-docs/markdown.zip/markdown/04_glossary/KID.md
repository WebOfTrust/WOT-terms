# KID

[KERI improvement doc](https://weboftrust.github.io/WOT-terms/docs/glossary/keri-improvement-doc.md)