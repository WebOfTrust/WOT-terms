# VID

[Verifiable Identifier](https://weboftrust.github.io/WOT-terms/docs/glossary/verifiable-identifier.md)