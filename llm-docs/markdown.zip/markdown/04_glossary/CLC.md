# CLC

[Chain link confidential](https://weboftrust.github.io/WOT-terms/docs/glossary/chain-link-confidentiality.md)