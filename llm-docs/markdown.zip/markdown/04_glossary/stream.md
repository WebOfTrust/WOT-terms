# stream

a [CESR](https://weboftrust.github.io/WOT-terms/docs/glossary/CESR.md) Stream is any set of concatenated Primitives, concatenated groups of Primitives, or hierarchically composed groups of [Primitives](https://weboftrust.github.io/WOT-terms/docs/glossary/primitives.md).
Source: Dr. S. Smith