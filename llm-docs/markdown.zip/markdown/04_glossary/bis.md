# bis

bis = backed vc issue, registry-backed transaction event log credential issuance