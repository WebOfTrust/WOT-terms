# NFT

[Non-fungible token](https://weboftrust.github.io/WOT-terms/docs/glossary/non-fungible-token.md)