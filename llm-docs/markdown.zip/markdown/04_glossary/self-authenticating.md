# self authenticating

[self-certifying](https://weboftrust.github.io/WOT-terms/docs/glossary/self-certifying-identifier.md)