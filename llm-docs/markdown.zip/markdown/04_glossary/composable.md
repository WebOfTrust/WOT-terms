# composable

[Composability](https://weboftrust.github.io/WOT-terms/docs/glossary/composability.md)