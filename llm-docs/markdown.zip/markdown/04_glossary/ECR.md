# ECR

[Engagement context role](https://weboftrust.github.io/WOT-terms/docs/glossary/engagement-context-role.md)