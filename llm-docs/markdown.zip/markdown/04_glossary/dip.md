# dip

dip = delcept, delegated inception