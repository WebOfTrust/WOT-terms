# KERI

[Key event receipt infrastructure](https://weboftrust.github.io/WOT-terms/docs/glossary/key-event-receipt-infrastructure.md)