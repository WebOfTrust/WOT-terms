# IANA

[Internet assigned numbers authority](https://weboftrust.github.io/WOT-terms/docs/glossary/internet-assigned-numbers-authority.md)