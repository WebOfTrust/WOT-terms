# juror

A juror has the basic task of performing [duplicity](https://weboftrust.github.io/WOT-terms/docs/glossary/duplicity.md) detection on events and event receipts.