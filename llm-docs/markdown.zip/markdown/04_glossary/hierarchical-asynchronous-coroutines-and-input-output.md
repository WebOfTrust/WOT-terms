# hierarchical-asynchronous-coroutines-and-input-output

HIO is an acronym which stands for 'Weightless hierarchical asynchronous coroutines and I/O in Python'.

It's Rich Flow Based Programming Hierarchical Structured Concurrency with Asynchronous IO. That mouthful of terms has been explained further on [Github](https://github.com/ioflo/hio).

HIO builds on very early work on hierarchical structured concurrency with lifecycle contexts from [ioflo](https://ioflo.com/), [ioflo github](https://github.com/ioflo/ioflo), and [ioflo manuals](https://github.com/ioflo/ioflo_manuals).

[Repo ioflo hio](https://github.com/ioflo/hio)