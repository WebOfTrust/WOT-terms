# persistent-identifier

[Transferable Identifiers](https://weboftrust.github.io/WOT-terms/docs/glossary/transferable-identifier.md)