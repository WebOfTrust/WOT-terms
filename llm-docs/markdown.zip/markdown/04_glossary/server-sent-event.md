# server-sent-event

Mailbox notifications; a streaming service for the agent U/I, to get notifications from the KERI system itself.