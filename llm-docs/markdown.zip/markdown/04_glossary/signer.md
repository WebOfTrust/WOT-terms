# signer

A primitive that represents a private key. It has the ability to create Sigers and Cigars (signatures).
[Source](https://github.com/WebOfTrust/cesride#terminology) by Jason Colburne