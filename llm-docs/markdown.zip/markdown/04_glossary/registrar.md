# registrar

identifiers that serve as backers for each [transaction event log](https://weboftrust.github.io/WOT-terms/docs/glossary/transaction-event-log.md) (TEL) under its provenance. This list of Registrars can be rotated with events specific to a certain type of TEL. In this way, a Registrar is analogous to a Backer in KERI KELs and Registrar lists are analogous to Backer lists in KERI KELs.