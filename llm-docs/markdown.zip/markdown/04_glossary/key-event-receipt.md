# key-event-receipt

message whose body references a Key event and whose attachments must include one or more signatures on that Key event.
Source [Sam Smith](https://github.com/WebOfTrust/ietf-keri/blob/main/draft-ssmith-keri.md#basic-terminology)