# GAR

[GLEIF authorized representative](https://weboftrust.github.io/WOT-terms/docs/glossary/gleif-authorized-representative.md)