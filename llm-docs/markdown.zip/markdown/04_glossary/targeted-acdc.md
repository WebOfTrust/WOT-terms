# untargeted-acdc

an ACDC without the presence of the Issuee field in the attribute or attribute aggregate sections.
Source: Dr. S. Smith

[Targeted ACDC](https://weboftrust.github.io/WOT-terms/docs/glossary/targeted-acdc.md)