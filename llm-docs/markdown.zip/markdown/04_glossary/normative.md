# normative

a theory is “normative” if it, in some sense, tells you what you should do - what action you should take. If it includes a usable procedure for determining the optimal action in a given scenario.
[Source](https://www.quora.com/What-is-the-difference-between-normative-and-non-normative?share=1).