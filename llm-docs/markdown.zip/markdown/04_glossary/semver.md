# semver

Semantic Versioning Specification 2.0. See also ([https://semver.org/)\[https://semver.org/\]](https://semver.org/\)%5Bhttps://semver.org/%5D).
Source: Dr. S.Smith