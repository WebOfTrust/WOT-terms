# keride

is a _Rust_ programming language library for [Key Event Receipt Infrastructure](https://weboftrust.github.io/WOT-terms/docs/glossary/key-event-receipt-infrastructure.md). Among its features is [CESR](https://weboftrust.github.io/WOT-terms/docs/glossary/CESR.md), signing, prefixing, pathing, and parsing.
More on [Github repo](https://github.com/WebOfTrust/keride)