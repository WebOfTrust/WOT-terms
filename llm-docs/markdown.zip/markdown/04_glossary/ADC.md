# ADC

[Authentic data container](https://weboftrust.github.io/WOT-terms/docs/glossary/authentic-data-container.md)