# KERIMask

A wallet similar to _MetaMask_, the manifestation will be a browser extension and it will connect to KERIA servers in order for a person to control AIDs from their browser.

As of October 2023 KERIMask is only planned.

[Signify keria request authentication protocol](https://weboftrust.github.io/WOT-terms/docs/glossary/signify-keria-request-authentication-protocol.md)