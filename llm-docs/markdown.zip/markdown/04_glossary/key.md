# stale-key

A stale key is an outdated or expired encryption key that should no longer be used for securing data

[Stale (key) event](https://weboftrust.github.io/WOT-terms/docs/glossary/stale-event.md)