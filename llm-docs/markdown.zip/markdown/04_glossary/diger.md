# diger

A _primitive_ that represents a [digest](https://weboftrust.github.io/WOT-terms/docs/glossary/digest.md). It has the ability to [verify](https://weboftrust.github.io/WOT-terms/docs/glossary/verify.md) that an input hashes to its raw value.
[Source](https://github.com/WebOfTrust/cesride#terminology) by Jason Colburne