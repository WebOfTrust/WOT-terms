# frame-code

[Framing code](https://weboftrust.github.io/WOT-terms/docs/glossary/framing-code.md)