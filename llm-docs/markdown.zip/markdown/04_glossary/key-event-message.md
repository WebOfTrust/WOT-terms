# key-event-message

Message whose body is a key event and whose attachments may include signatures on its body.
Source [Sam Smith](https://github.com/WebOfTrust/ietf-keri/blob/main/draft-ssmith-keri.md#basic-terminology)