# ephemeral

Lasting for a markedly brief time. Having a short lifespan.
In the context of identifiers is often referred to as identifiers for one time use; or throw-away identifiers.