# SSI

[Self-sovereign identity](https://weboftrust.github.io/WOT-terms/docs/glossary/self-sovereign-identity.md)