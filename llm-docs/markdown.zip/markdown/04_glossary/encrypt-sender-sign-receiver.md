# encrypt-sender-sign-receiver

An authenticated encryption approach, using [PKI](https://weboftrust.github.io/WOT-terms/docs/glossary/PKI.md). It covers [authenticity](https://weboftrust.github.io/WOT-terms/docs/glossary/authenticity.md) and [confidentiality](https://weboftrust.github.io/WOT-terms/docs/glossary/confidentiality.md).