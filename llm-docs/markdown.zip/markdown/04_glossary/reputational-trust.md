# reputational-trust

Established by a trusted party offering [Identity Assurance](https://weboftrust.github.io/WOT-terms/docs/glossary/identity-assurance.md).