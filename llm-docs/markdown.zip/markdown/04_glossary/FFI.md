# FFI

[Foreign Function Interface](https://weboftrust.github.io/WOT-terms/docs/glossary/foreign-function-interface.md)