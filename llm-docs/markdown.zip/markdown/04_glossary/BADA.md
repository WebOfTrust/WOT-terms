# BADA

[Best available data acceptance mechanism](https://weboftrust.github.io/WOT-terms/docs/glossary/best-available-data-acceptance-mechanism.md)