# CBOR

[Concise Binary Object Representation](https://weboftrust.github.io/WOT-terms/docs/glossary/concise-binary-object-representation.md)