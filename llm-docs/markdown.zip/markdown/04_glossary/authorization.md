# broken-object-level-authorization

Refers to [security](https://weboftrust.github.io/WOT-terms/docs/glossary/security.md) flaws where users can access data they shouldn't, due to inadequate permission checks on individual (sub)objects.