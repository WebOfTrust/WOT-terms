# information-theoretic-security

the highest level of cryptographic security concerning a cryptographic secret (seed, salt, or private key).
Source: Dr. S. Smith