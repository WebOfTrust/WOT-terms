# vLEI

[Verifiable legal entity identifier](https://weboftrust.github.io/WOT-terms/docs/glossary/verifiable-legal-entity-identifier.md)