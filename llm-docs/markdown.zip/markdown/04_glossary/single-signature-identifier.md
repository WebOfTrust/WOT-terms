# single-signature-identifier

or single sig identifier; is an identifier controlled by a one-of-one signing [keypair](https://weboftrust.github.io/WOT-terms/docs/glossary/key-pair.md)