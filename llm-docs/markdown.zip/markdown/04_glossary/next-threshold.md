# next-threshold

represents the number or fractional weights of signatures from the given set of next keys required to be attached to a [Message](https://trustoverip.github.io/tswg-keri-specification/#term:message) for the [Message](https://trustoverip.github.io/tswg-keri-specification/#term:message) to be considered fully signed.