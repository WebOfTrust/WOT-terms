# passcode

A password, sometimes called a passcode (for example in [Apple](https://en.wikipedia.org/wiki/Apple_Inc.) devices), is secret data, typically a string of characters, usually used to confirm a user's identity.
More on source [Wikipedia](https://en.wikipedia.org/wiki/Password)