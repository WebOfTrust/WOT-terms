# partial-pre-rotation

[Partial rotation](https://weboftrust.github.io/WOT-terms/docs/glossary/partial-rotation.md)