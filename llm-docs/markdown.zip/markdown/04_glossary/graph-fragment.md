# graph-fragment

An ACDC is a verifiable data structure and _part of a graph_, consisting of a node property and one or two edge proporties.

![](https://hackmd.io/_uploads/r1KDqKxzj.png)