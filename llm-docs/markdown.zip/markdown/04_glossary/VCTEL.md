# VCTEL

[Virtual credential transaction event log](https://weboftrust.github.io/WOT-terms/docs/glossary/virtual-credential-transaction-event-log.md)