# PGP

[Pretty good privacy](https://weboftrust.github.io/WOT-terms/docs/glossary/pretty-good-privacy.md)