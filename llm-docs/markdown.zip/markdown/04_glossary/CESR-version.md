# CESR-version

the CESR Version is provided by a special Count Code that specifies the Version of all the CESR code tables in a given Stream or Stream section.
Source: Dr. S. Smith