# locked-state

The default status a KERI data store is in once it has been created using a [passcode](https://weboftrust.github.io/WOT-terms/docs/glossary/passcode.md); it is by default encrypted.