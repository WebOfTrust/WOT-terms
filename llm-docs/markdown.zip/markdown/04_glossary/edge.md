# edge

a top-level field map within an ACDC that provides edges that connect to other ACDCs, forming a labeled property graph (LPG).
Source: Dr. S. Smith