# QAR

[QVI Authorized Representative](https://weboftrust.github.io/WOT-terms/docs/glossary/qvi-authorized-representative.md)