# keri-ox

The RUST programming-language implementation of the [KERI](https://github.com/trustoverip/acdc/wiki/KERI) protocol.