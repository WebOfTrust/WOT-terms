# VC

[Verifiable credential](https://weboftrust.github.io/WOT-terms/docs/glossary/verifiable-credential.md)