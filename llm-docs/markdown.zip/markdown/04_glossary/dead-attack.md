# Dead attack

an attack on an [establishment event](https://weboftrust.github.io/WOT-terms/docs/glossary/establishment-event.md) that occurs after the Key-state for that event has become stale because a later establishment event has rotated the sets of signing and pre-rotated keys to new sets.

Security Properties of [Pre-rotation](https://weboftrust.github.io/WOT-terms/docs/glossary/Pre-rotation.md).
Source: Dr. S.Smith, 2024