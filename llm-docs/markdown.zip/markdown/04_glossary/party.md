# party

An entity who participates or is concerned in an action, proceeding, plan, etc.
Source: ToIP