# AVR

[Authorized vLEI Representative](https://weboftrust.github.io/WOT-terms/docs/glossary/authorized-vlei-representative.md)