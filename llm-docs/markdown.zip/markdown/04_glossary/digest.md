# signed-digest

commitment to content, by digitally signing a digest of this content.