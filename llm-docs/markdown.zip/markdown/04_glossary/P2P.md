# P2P

[Peer to peer](https://weboftrust.github.io/WOT-terms/docs/glossary/peer-to-peer.md)