# habery

'Hab' comes from ‘Habitat’. It’s a place where multi-sigs and AIDs are linked. Habery manages a collection of [Habs](https://weboftrust.github.io/WOT-terms/docs/glossary/hab.md). A Hab is a data structure (a Python object).

The only hit (2022) in a Google search pointing to a github site 'habery DOT github DOT io' is NOT related.

| TBW |-prio2