# SAD

[Self addressing data](https://weboftrust.github.io/WOT-terms/docs/glossary/self-addressing-data.md)