# DID

[Decentralized Identifier](https://github.com/trustoverip/acdc/wiki/decentralized-identifier)