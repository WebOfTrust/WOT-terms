# agency

Agents can be people, edge computers and the functionality within [wallets](https://github.com/trustoverip/acdc/wiki/_new#digital-identity-wallet). The service an agent offers is [agency](https://weboftrust.github.io/WOT-terms/docs/glossary/agency.md).