# DAG

[Directed acyclic graph](https://weboftrust.github.io/WOT-terms/docs/glossary/directed-acyclic-graph.md)