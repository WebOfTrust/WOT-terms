# JSON

[JavaScript Object Notation](https://weboftrust.github.io/WOT-terms/docs/glossary/javascript-object-notation.md)