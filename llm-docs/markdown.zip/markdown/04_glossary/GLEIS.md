# GLEIS

Global Legal Entity Identifier System