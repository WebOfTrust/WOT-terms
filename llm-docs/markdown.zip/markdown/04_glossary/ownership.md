# ownership

[Ownership](https://github.com/trustoverip/toip/wiki/ownership) in ToIP glossary