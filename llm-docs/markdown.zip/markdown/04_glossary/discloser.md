# discloser

a role of an entity that discloses an [ACDC](https://weboftrust.github.io/WOT-terms/docs/glossary/authentic-chained-data-container.md). A Discloser may or may not be the Issuer of the disclosed ACDC.
Source: Dr. S. Smith