# provenance

From Wikipedia ([Source](https://en.wikipedia.org/wiki/Provenance)):

Provenance (from the [French](https://en.wikipedia.org/wiki/French_language) provenir, 'to come from/forth') is the chronology of the ownership, custody or location of a historical object. The term was originally mostly used in relation to [works of art](https://en.wikipedia.org/wiki/Works_of_art) but is now used in similar senses in a wide range of fields, including [archaeology](https://en.wikipedia.org/wiki/Archaeology), [paleontology](https://en.wikipedia.org/wiki/Paleontology), [archives](https://en.wikipedia.org/wiki/Archive), [manuscripts](https://en.wikipedia.org/wiki/Manuscript), printed books, the [circular economy](https://en.wikipedia.org/wiki/Circular_economy), and science and computing.

The primary purpose of tracing the provenance of an object or entity is normally to provide contextual and circumstantial evidence for its original production or discovery, by establishing, as far as practicable, its later history, especially the sequences of its formal ownership, custody and places of storage. The practice has a particular value in helping [authenticate](https://en.wikipedia.org/wiki/Authentication) objects. Comparative techniques, expert opinions and the results of scientific tests may also be used to these ends, but establishing provenance is essentially a matter of [documentation](https://en.wikipedia.org/wiki/Document). The term dates to the 1780s in English. Provenance is conceptually comparable to the legal term [chain of custody](https://en.wikipedia.org/wiki/Chain_of_custody).
([Source](https://en.wikipedia.org/wiki/Provenance))

[Authentic chained data containers (ACDC)](https://weboftrust.github.io/WOT-terms/docs/glossary/authentic-chained-data-container.md) establish provenance in two coherent ways:

-   historic documentation of cryptographic verifiable key states and data consistency (result: secure attribution)
-   historic documentation of [credentials](https://weboftrust.github.io/WOT-terms/docs/glossary/credential.md) (result: attested [veracity](https://weboftrust.github.io/WOT-terms/docs/glossary/veracity.md))
    (_@henkvancann_)