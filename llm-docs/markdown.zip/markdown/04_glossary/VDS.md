# VDS

[Verifiable data structure](https://weboftrust.github.io/WOT-terms/docs/glossary/verifiable-data-structure.md)