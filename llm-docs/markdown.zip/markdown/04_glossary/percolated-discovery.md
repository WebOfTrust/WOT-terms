# percolated-discovery

a discovery mechanism for information associated with an AID or a SAID, which is based on Invasion Percolation Theory. Once an entity has discovered such information, it may in turn share what it discovers with other entities. Since the information so discovered is end-verifiable, the percolation mechanism and percolating intermediaries do not need to be trusted.
Source: Dr. S. Smith

[Percolated information discovery](https://weboftrust.github.io/WOT-terms/docs/glossary/percolated-information-discovery.md)