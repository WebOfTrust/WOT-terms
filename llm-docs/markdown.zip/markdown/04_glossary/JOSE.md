# JOSE

[Javascript object signing and encryption](https://weboftrust.github.io/WOT-terms/docs/glossary/javascript-object-signing-and-encryption.md)