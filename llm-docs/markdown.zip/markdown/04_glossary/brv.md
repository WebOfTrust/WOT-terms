# brv

brv = backed vc revoke, registry-backed transaction event log credential revocation