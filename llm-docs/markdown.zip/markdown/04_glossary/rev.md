# rev

rev = vc revoke, verifiable credential revocation