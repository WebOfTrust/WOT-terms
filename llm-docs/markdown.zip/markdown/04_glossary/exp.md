# exp

exp = expose, sealed data exposition