# IPEX

[Issuance and presentation exchange protocol](https://weboftrust.github.io/WOT-terms/docs/glossary/issuance-and-presentation-exchange-protocol.md)