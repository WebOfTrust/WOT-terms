# PTEL

[Public transaction event log](https://weboftrust.github.io/WOT-terms/docs/glossary/public-transaction-event-log.md)