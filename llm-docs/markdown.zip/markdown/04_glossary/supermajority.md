# supermajority

Sufficient majority that is labeled _immune_ from certain kinds of attacks or faults.