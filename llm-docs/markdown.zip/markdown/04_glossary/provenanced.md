# provenanced

The act of verifying [authenticity](https://weboftrust.github.io/WOT-terms/docs/glossary/authenticity.md) or quality of documented history or origin of something.

Focus on authenticity. See [provenance](https://weboftrust.github.io/WOT-terms/docs/glossary/provenance.md).