# reputation

Consistent behaviour over time on the basis of which anyone else makes near-future decisions.
Source: Samuel Smith at IIW37.