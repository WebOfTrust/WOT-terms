# TEE

[trusted execution environment](https://weboftrust.github.io/WOT-terms/docs/glossary/trusted-execution-environment.md)