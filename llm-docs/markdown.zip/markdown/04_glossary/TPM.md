# TPM

[Trusted platform module](https://weboftrust.github.io/WOT-terms/docs/glossary/trusted-platform-module.md)