# TOAD

[threshold of accountable duplicity](https://weboftrust.github.io/WOT-terms/docs/glossary/threshold-of-accountable-duplicity.md)