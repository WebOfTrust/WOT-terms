# UI

[User interface](https://weboftrust.github.io/WOT-terms/docs/glossary/user-interface.md)