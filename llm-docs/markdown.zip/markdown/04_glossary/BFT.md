# BFT

[Byzantine fault tolerance](https://weboftrust.github.io/WOT-terms/docs/glossary/byzantine-fault-tolerance.md)