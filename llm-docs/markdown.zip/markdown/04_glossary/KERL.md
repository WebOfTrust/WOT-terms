# KERL

[Key event receipt log](https://weboftrust.github.io/WOT-terms/docs/glossary/key-event-receipt-log.md)