# LID

[Legitimized human meaningful identifier](https://weboftrust.github.io/WOT-terms/docs/glossary/legitimized-human-meaningful-identifier.md)