# quadlet

a group of 4 characters in the T domain and equivalently in triplets of 3 bytes each in the B domain used to define variable size.
Source: Dr. S. Smith