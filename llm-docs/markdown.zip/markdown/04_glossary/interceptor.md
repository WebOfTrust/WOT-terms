# interceptor

a [keria](https://weboftrust.github.io/WOT-terms/docs/glossary/keria.md) class that allows to push events that are happening inside the cloud agent to other backend processes. It is similar to the notifier class but it is used to "notify" other web services.

[https://github.com/WebOfTrust/keria/pull/67](https://github.com/WebOfTrust/keria/pull/67)