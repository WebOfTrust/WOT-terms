# MFA

[Multi-factor Authentication](https://weboftrust.github.io/WOT-terms/docs/glossary/multi-factor-authentication.md)