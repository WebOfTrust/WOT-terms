# DAR

[Designated Authorized Representatives](https://weboftrust.github.io/WOT-terms/docs/glossary/designated-authorized-representative.md)