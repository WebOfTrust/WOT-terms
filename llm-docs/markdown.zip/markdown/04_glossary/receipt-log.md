# receipt-log

ordered record of all key event receipts for a given set of witnesses.