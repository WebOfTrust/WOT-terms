# dnd

Do Not Delegate is a flag/attribute for an AID, and this is default set to "you can delegate."