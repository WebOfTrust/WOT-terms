# receipt

event message or reference with one or more witness signatures.

See Also:
[key event receipt](https://weboftrust.github.io/WOT-terms/docs/glossary/key-event-receipt.md)