# SKRAP

[Signify/KERIA Request Authentication Protocol](https://weboftrust.github.io/WOT-terms/docs/glossary/signify-keria-request-authentication-protocol.md)