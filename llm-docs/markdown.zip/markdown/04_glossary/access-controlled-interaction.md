# access-controlled-interaction

Access controlled actions like submitting a report. If you already have that report then load balancer needs a mechanism to drop repeated requests.

Source: Samuel Smith / Daniel Hardman / Lance Byrd - Zoom meeting KERI Suite Jan 16 2024; discussion minute 30-60 min

Replay attacks are less of a concern, other than DDoS attack using resubmissions.

[Registration Interaction](https://weboftrust.github.io/WOT-terms/docs/glossary/registration-interaction.md)