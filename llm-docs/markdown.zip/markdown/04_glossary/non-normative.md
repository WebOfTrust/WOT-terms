# non-normative

A theory is called non-normative if it does not do what has described under '[Normative](https://weboftrust.github.io/WOT-terms/docs/glossary/normative.md)'. In general, the purpose of non-normative theories is not to give answers, but rather to describe possibilities or predict what might happen as a result of certain actions.
[Source](https://www.quora.com/What-is-the-difference-between-normative-and-non-normative?share=1).