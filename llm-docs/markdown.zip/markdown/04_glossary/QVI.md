# QVI

[Qualified vLEI issuer](https://weboftrust.github.io/WOT-terms/docs/glossary/qualified-vlei-issuer.md)