# owner

[Owner](https://github.com/trustoverip/toip/wiki/owner) in ToIP glossary