# GLEIF

Global Legal Entity Identifier Foundation

[https://www.gleif.org/en](https://www.gleif.org/en)