# qry

qry = query