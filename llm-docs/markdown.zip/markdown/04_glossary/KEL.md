# KEL

A Key Event Log.

[Key Event Log](https://weboftrust.github.io/WOT-terms/docs/glossary/key-event-log.md)