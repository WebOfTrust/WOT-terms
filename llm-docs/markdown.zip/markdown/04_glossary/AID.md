# SAID

[Self-addressing identifier](https://weboftrust.github.io/WOT-terms/docs/glossary/self-addressing-identifier.md)