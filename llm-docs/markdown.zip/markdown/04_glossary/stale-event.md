# stale-event

A stale key event is an outdated or irrelevant (key) event involving an [expired encryption key](https://weboftrust.github.io/WOT-terms/docs/glossary/stale-key.md) that may compromise security.