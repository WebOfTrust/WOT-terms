# DEL

[Duplicitous event log](https://weboftrust.github.io/WOT-terms/docs/glossary/duplicitous-event-log.md)