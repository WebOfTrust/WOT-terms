# jury

The jury is the set of entities or components acting as [jurors](https://weboftrust.github.io/WOT-terms/docs/glossary/juror.md).