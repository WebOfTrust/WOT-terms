# strip-parameter

tells us what part of the [CESR](https://weboftrust.github.io/WOT-terms/docs/glossary/CESR.md) stream will be parsed by which code.

[Parside](https://weboftrust.github.io/WOT-terms/docs/glossary/parside.md)

| TBW |