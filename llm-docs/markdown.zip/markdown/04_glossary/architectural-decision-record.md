# architectural-decision-record

Is a justified software design choice that addresses a functional or non-functional requirement that is architecturally significant.
[Source adr.github.io](https://adr.github.io/)