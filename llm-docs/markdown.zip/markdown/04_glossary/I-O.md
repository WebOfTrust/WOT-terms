# I-O

[Input output](https://weboftrust.github.io/WOT-terms/docs/glossary/input-output.md)