# HSM

[Hardware security model](https://weboftrust.github.io/WOT-terms/docs/glossary/hardware-security-module.md)