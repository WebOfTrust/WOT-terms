# listed-identifier

Is a list in an [ACDC](https://weboftrust.github.io/WOT-terms/docs/glossary/authentic-chained-data-container.md) of authorised did:webs identifier + method; the list appears in the metadata of the did:webs DID-doc.
Source: paraphrased Samuel Smith, Zoom meeting _KERI dev_ Thursday Nov 9 2023