# TCP

[Transmission control protocol](https://weboftrust.github.io/WOT-terms/docs/glossary/transmission-control-protocol.md)