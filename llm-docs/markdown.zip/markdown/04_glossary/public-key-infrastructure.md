# public-key-infrastructure

Is a set of roles, policies, hardware, software and procedures needed to create, manage, distribute, use, store and revoke digital certificates and manage public-key encryption.

![Public Private Key caveat to KERI](https://github.com/WebOfTrust/keri/blob/main/images/pubprivkey-caveat.png?raw=true)

More on [Wikipedia](https://en.wikipedia.org/wiki/Public_key_infrastructure)