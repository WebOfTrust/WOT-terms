# salter

A primitive that represents a [seed](https://weboftrust.github.io/WOT-terms/docs/glossary/seed.md). It has the ability to generate new [Signer](https://weboftrust.github.io/WOT-terms/docs/glossary/signer.md)s.
[Source](https://github.com/WebOfTrust/cesride#terminology) by Jason Colburne