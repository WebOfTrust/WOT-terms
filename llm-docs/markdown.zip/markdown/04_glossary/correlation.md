# unpermissioned-correlation

a correlation established between two or more disclosed ACDCs whereby the discloser of the ACDCs does not permit the disclosee to establish such a correlation.
Source: Dr. S. Smith