# PID

[percolated information discovery](https://weboftrust.github.io/WOT-terms/docs/glossary/percolated-information-discovery.md)