# hab

A Hab is a keystore for one identifier. The Python implementation in [KERIpy](https://weboftrust.github.io/WOT-terms/docs/glossary/keripy.md), also used by [KERIA](https://weboftrust.github.io/WOT-terms/docs/glossary/keria.md) uses [LMDB](http://www.lmdb.tech/doc/) to store key material and all other data.

Many Habs are included within and managed by a [Habery](https://weboftrust.github.io/WOT-terms/docs/glossary/habery.md).