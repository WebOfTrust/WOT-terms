# attribute

a top-level [field map](https://weboftrust.github.io/WOT-terms/docs/glossary/field-map.md) within an [ACDC](https://weboftrust.github.io/WOT-terms/docs/glossary/ACDC.md) that provides a property of an entity that is inherent or assigned to the entity.
Source: Dr. S. Smith