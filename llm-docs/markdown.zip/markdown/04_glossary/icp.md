# icp

icp = incept, inception