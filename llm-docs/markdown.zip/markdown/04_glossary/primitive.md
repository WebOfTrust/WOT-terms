# primitive

a serialization of a unitary value. All Primitives in KERI must be expressed in [CESR](https://weboftrust.github.io/WOT-terms/docs/glossary/composable-event-streaming-representation.md).
Source: Dr. S.Smith

In general in computing a 'primitive' is the simplest type of programming language item. It may also refer to the smallest processing unit accessible by a programmer.
[Source](https://www.techopedia.com/definition/3860/primitive)

See [Cryptographic primitive](https://weboftrust.github.io/WOT-terms/docs/glossary/cryptographic-primitive.md)

In KERI and ACDC it a serialization of a unitary value. A [cryptographic primitive](https://weboftrust.github.io/WOT-terms/docs/glossary/cryptographic-primitive.md) is the KERI-suite sense is the serialization of a value associated with a cryptographic operation including but not limited to a digest (hash), a salt, a seed, a private key, a public key, or a signature. All primitives in KERI MUST be expressed in [CESR](https://weboftrust.github.io/WOT-terms/docs/glossary/composable-event-streaming-representation.md).