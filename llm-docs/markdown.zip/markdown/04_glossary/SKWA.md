# SKWA

[Simple KERI for web auth](https://weboftrust.github.io/WOT-terms/docs/glossary/simple-keri-for-web-auth.md)