# KERIA-agent

An [agent](https://weboftrust.github.io/WOT-terms/docs/glossary/agent.md) in [KERIA](https://weboftrust.github.io/WOT-terms/docs/glossary/keria.md) terms, is an instance of a keystore ([Hab](https://weboftrust.github.io/WOT-terms/docs/glossary/hab.md)) that runs in a given instance of the KERIA agent server.