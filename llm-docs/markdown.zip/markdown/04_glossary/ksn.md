# ksn

ksn = state, key state notice