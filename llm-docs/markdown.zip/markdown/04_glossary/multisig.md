# multisig

also multi-signature or multisignature; is a [digital signature](https://en.wikipedia.org/wiki/Digital_signature) scheme which allows a group of users to sign a single piece of digital data.
Paraphrased by @henkvancann from Wikipedia [source](https://en.wikipedia.org/wiki/Multisignature)

The KERI team has conceptually chosen for minimal sufficient means and so-called _dumb crypto_: "'Dumb technology' is freely available, understandable to everyone and easy to implement. In our case: just hashes and digital signatures."

KERI has thresholded set of [non-repudiable](https://weboftrust.github.io/WOT-terms/docs/glossary/non-repudiable.md) signatures.
KERI's CESR, and therefore KERI and ACDC is extensible with the latest more sophisticated multi-signature schemes like Schnorr signatures.