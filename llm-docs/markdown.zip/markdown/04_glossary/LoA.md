# LoA

[Levels of assurance](https://weboftrust.github.io/WOT-terms/docs/glossary/levels-of-assurance.md)