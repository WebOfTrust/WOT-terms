# rct

rct = receipt