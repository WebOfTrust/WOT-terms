# KRAM

[KERI Request Authentication Method](https://weboftrust.github.io/WOT-terms/docs/glossary/keri-request-authentication-method.md)