# URL

[Uniform resource locator](https://weboftrust.github.io/WOT-terms/docs/glossary/uniform-resource-locator.md)