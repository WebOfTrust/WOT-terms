# ITPS

[Information theoretic security](https://weboftrust.github.io/WOT-terms/docs/glossary/information-theoretic-security.md)