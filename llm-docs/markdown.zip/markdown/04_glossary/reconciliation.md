# reconciliation

Reconciliation is the process in which you decide to accept a fork of the [KEL](https://weboftrust.github.io/WOT-terms/docs/glossary/key-event-log.md) or not.
Source: Samuel Smith, Zoom meeting Jan 2 2024.

-   You might not have to abandon your identifier after key compromise
-   Only few people will see your reconciliation or clean up