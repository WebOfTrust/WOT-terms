# cigar

An **_un_**[indexed signature](https://weboftrust.github.io/WOT-terms/docs/glossary/indexed-signature.md).
[Source](https://github.com/WebOfTrust/cesride#terminology) by Jason Colburne