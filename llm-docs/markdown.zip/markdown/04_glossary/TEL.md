# management-TEL

[Management transaction event log](https://weboftrust.github.io/WOT-terms/docs/glossary/management-transaction-event-log.md)