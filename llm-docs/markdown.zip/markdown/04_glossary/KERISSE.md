# KERISSE

[KERI suite search engine](https://weboftrust.github.io/WOT-terms/docs/glossary/keri-suite-search-engine.md)