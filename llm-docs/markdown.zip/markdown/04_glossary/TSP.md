# TSP

[Trust Spanning Protocol](https://weboftrust.github.io/WOT-terms/docs/glossary/trust-spanning-protocol.md)