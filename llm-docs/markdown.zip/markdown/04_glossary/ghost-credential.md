# ghost-credential

Is a valid credential within in a 90 days grace period (the revocation transaction time frame before it's booked to revocation registry).

When a relationship needs to be terminated with a [QVI](https://weboftrust.github.io/WOT-terms/docs/glossary/QVI.md) and the QVI has not revoked their credentials (yet) then those credentials become ghost credentials.

| TBW prio 3 |