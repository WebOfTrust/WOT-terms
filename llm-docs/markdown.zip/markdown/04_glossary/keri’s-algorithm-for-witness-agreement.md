# keri’s-algorithm-for-witness-agreement

a type of Byzantine Fault Tolerant ([BFT](https://weboftrust.github.io/WOT-terms/docs/glossary/byzantine-fault-tolerance.md)) algorithm.
Source: Dr. S.Smith