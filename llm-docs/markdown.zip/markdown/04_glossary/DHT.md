# DHT

[Distributed hash table](https://weboftrust.github.io/WOT-terms/docs/glossary/distributed-hash-table.md)