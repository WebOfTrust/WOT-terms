# interoperable

[Interoperability](https://weboftrust.github.io/WOT-terms/docs/glossary/interoperability.md)