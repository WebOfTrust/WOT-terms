# interaction-event

Non-establishment Event that anchors external data to the key-state as established by the most recent prior establishment event.
Source [Sam Smith](https://github.com/WebOfTrust/ietf-keri/blob/main/draft-ssmith-keri.md#basic-terminology)