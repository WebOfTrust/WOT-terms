# group-code

[Group framing code](https://weboftrust.github.io/WOT-terms/docs/glossary/group-framing-code.md)