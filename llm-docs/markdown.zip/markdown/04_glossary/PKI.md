# PKI

[Public key infrastructure](https://weboftrust.github.io/WOT-terms/docs/glossary/public-key-infrastructure.md)