# hio

Weightless hierarchical asynchronous coroutines and I/O in Python.
Rich Flow Based Programming Hierarchical Structured Concurrency with Asynchronous IO.

This very technical topic can best be studied further at the Github [Repository](https://github.com/ioflo/hio)

Choosing HIO complies with the asynchronous nature of KERI, the minimal sufficient means design principle of KERI and the leading KERIpy implementation.