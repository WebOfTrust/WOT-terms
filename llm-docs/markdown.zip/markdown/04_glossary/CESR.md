# CESR

[composable event streaming representation](https://weboftrust.github.io/WOT-terms/docs/glossary/composable-event-streaming-representation.md)