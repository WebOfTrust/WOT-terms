# MIME-type

[Media type](https://weboftrust.github.io/WOT-terms/docs/glossary/media-type.md)