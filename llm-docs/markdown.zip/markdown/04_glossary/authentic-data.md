# authentic-data

[Integer](https://weboftrust.github.io/WOT-terms/docs/glossary/integrity.md) and [Provenanced](https://weboftrust.github.io/WOT-terms/docs/glossary/provenance.md) data.
Source: Timothy Ruff, #IIW37