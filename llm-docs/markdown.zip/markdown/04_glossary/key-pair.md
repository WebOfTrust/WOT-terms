# key-pair

is a private key and its corresponding public key resulting from a one-way crypto-graphical function; a key pair is used with an asymmetric-key (public-key) algorithm in a so called [Public Key Infrastructure](https://weboftrust.github.io/WOT-terms/docs/glossary/public-key-infrastructure.md) (PKI).