# KA2CE

[KERI agreement algorithm for control establishment](https://weboftrust.github.io/WOT-terms/docs/glossary/keri-agreement-algorithm-for-control-establishment.md)