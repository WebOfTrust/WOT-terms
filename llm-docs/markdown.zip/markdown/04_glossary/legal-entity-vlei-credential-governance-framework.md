# legal-entity-vlei-credential-governance-framework

A _document_ that details the requirements for vLEI Credential **issued by** a [Qualified vLEI Issuer](https://weboftrust.github.io/WOT-terms/docs/glossary/qualified-vlei-issuer.md) to a [Legal Entity](https://weboftrust.github.io/WOT-terms/docs/glossary/legal-entity.md).