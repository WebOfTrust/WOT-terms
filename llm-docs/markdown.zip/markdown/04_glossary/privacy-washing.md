# privacy-washing

De-identification so that it provides a personal data safe harbour and could be legally acceptable forwarded.

We might need legally enforced pressure for it to be no longer acceptable that you've _un-seen_ the (re-identifiable) personal data.
"Once you see, you can't un-see".