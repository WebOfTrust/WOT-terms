# ADR

[Architectural Decision Record](https://weboftrust.github.io/WOT-terms/docs/glossary/architectural-decision-record.md)