# BOLA

[Broken Object Level Authorization](https://weboftrust.github.io/WOT-terms/docs/glossary/broken-object-level-authorization.md)