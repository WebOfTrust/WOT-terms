# SCID

[Self-certifying identifier](https://weboftrust.github.io/WOT-terms/docs/glossary/self-certifying-identifier.md)