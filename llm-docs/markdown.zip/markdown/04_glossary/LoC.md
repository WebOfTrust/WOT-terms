# LoC

[Loci of control](https://weboftrust.github.io/WOT-terms/docs/glossary/loci-of-control.md)