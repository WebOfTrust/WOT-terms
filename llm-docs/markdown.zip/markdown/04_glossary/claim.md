# claim

An assertion of the truth of something, typically one which is disputed or in doubt. A set of claims might convey personally identifying information: name, address, date of birth and citizenship, for example. ([Source](https://www.identityblog.com/?p=352)).