# authentic-provenance-chain

Interlinked [presentations](https://weboftrust.github.io/WOT-terms/docs/glossary/presentation-exchange.md) of evidence that allow data to be tracked back to its origin in an objectively [verifiable](https://weboftrust.github.io/WOT-terms/docs/glossary/verifiable.md) way.