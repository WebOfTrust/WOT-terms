# schema

the [SAID](https://weboftrust.github.io/WOT-terms/docs/glossary/said.md) of a JSON schema that is used to issue and verify an ACDC.
Source: Dr. S.Smith